package com.example.loginfirebasemail77;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import models.Productos;

public class ListaProductosAdapter extends RecyclerView.Adapter<ListaProductosAdapter.ViewHolder> {

    private ArrayList<Productos> dataset;

    public ListaProductosAdapter() {
        dataset = new ArrayList<>();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_productes, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Productos p = dataset.get(position);

        holder.nombreTextView.setText(p.getName());


    }

    @Override
    public int getItemCount() {
        return dataset.size();
    }

    public void adicionarListaProductos(ArrayList<Productos> listaproductos) {
        dataset.addAll(listaproductos);
        notifyDataSetChanged();
    }

    public class  ViewHolder extends RecyclerView.ViewHolder {

        private TextView nombreTextView;
        public ViewHolder(View itemView) {
            super(itemView);

            nombreTextView = (TextView) itemView.findViewById(R.id.nombreTextView);

        }

    }
}
