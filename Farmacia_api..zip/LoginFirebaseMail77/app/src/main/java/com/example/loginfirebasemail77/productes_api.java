package com.example.loginfirebasemail77;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;

import farmaciaapi.farmaciaapiservice;
import models.Productos;
import models.productosrespuesta;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class productes_api extends AppCompatActivity {

    private static final String TAG = "Productos";

    private  Retrofit retrofit;

    private RecyclerView recyclerView;
    private ListaProductosAdapter listaProductosAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.productes_api);


        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        listaProductosAdapter = new ListaProductosAdapter();
        recyclerView.setAdapter(listaProductosAdapter);
        recyclerView.setHasFixedSize(true);
        GridLayoutManager layoutManager = new GridLayoutManager(this, 3);
        recyclerView.setLayoutManager(layoutManager);


        retrofit = new Retrofit.Builder()
                .baseUrl("https://reqres.in/api/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        ObtenerDatos();

    }

    private void ObtenerDatos() {
        farmaciaapiservice service = retrofit.create(farmaciaapiservice.class);
        Call<productosrespuesta> productosrespuestaCall = service.obtenerproductos();

        productosrespuestaCall.enqueue(new Callback<productosrespuesta>() {
            @Override
            public void onResponse(Call<productosrespuesta> call, Response<productosrespuesta> response) {

                if (response.isSuccessful()) {
                    productosrespuesta productosrespuesta = response.body();
                    ArrayList<Productos> listaproductos = productosrespuesta.getResults();

                   listaProductosAdapter.adicionarListaProductos(listaproductos);

                } else{
                    Log.e(TAG, "onResponse: " + response.errorBody());
                }
            }

            @Override
            public void onFailure(Call<productosrespuesta> call, Throwable t) {

                Log.e(TAG, "onFailure: " + t.getMessage());

            }
        });
    }
}