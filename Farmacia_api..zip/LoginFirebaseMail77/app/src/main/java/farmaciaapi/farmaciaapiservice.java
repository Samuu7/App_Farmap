package farmaciaapi;

import models.productosrespuesta;
import retrofit2.Call;
import retrofit2.http.GET;

public interface farmaciaapiservice {

    @GET("users")
    Call<productosrespuesta> obtenerproductos();
}
