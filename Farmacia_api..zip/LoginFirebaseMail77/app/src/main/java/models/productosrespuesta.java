package models;

import java.util.ArrayList;

public class productosrespuesta {

    private ArrayList<Productos> results;

    public ArrayList<Productos> getResults() {
        return results;
    }

    public void setResults(ArrayList<Productos> results) {
        this.results = results;
    }
}
